@echo off
rem Plan B: builds the Cities: Skylines mod as a DLL against your game, for when the game can't compile the source.
rem Needs the .NET SDK: https://dotnet.microsoft.com/download
rem If Cities: Skylines isn't in the default Steam folder, run:  BUILD_WITH_DOTNET.bat "D:\...\Cities_Skylines"
setlocal
set "GAME=%~1"
if "%GAME%"=="" set "GAME=C:\Program Files (x86)\Steam\steamapps\common\Cities_Skylines"
if not exist "%GAME%\Cities_Data\Managed\Assembly-CSharp.dll" (
  echo Cities: Skylines not found at "%GAME%".
  echo Run: BUILD_WITH_DOTNET.bat "path\to\Cities_Skylines"
  pause & exit /b 1
)
where dotnet >nul 2>nul || (echo The .NET SDK is not installed: https://dotnet.microsoft.com/download & pause & exit /b 1)
dotnet build -c Release "%~dp0build\RaccoonCitySkylines.csproj" -p:CitiesManaged="%GAME%\Cities_Data\Managed" || (pause & exit /b 1)
rem The DLL replaces the source copy, so the game doesn't load the mod twice.
set "MOD=%LOCALAPPDATA%\Colossal Order\Cities_Skylines\Addons\Mods\RaccoonCitySkylines"
if exist "%MOD%\Source" rmdir /s /q "%MOD%\Source"
echo.
echo Installed the built mod to "%MOD%". Enable it in Content Manager ^> Mods.
pause
