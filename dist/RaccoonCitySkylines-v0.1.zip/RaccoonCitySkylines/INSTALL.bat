@echo off
rem Raccoon City Skylines installer. Copies the Cities: Skylines mod and the RE2 files into place.
rem   INSTALL.bat            install
rem   INSTALL.bat /remove    remove everything this installed
setlocal EnableExtensions
set "HERE=%~dp0"
set "MOD=%LOCALAPPDATA%\Colossal Order\Cities_Skylines\Addons\Mods\RaccoonCitySkylines"
set "RE2=C:\Program Files (x86)\Steam\steamapps\common\RESIDENT EVIL 2  BIOHAZARD RE2"
if not exist "%RE2%\re2.exe" (
  echo Resident Evil 2 was not found in the default Steam folder.
  echo In Steam: right-click Resident Evil 2 ^> Manage ^> Browse local files, and copy that folder's path.
  set /p "RE2=Paste RE2's folder (the one with re2.exe): "
)
set "RE2=%RE2:"=%"
if not exist "%RE2%\re2.exe" (echo No re2.exe in "%RE2%". & pause & exit /b 1)

if /i "%~1"=="/remove" goto remove

echo.
echo === Cities: Skylines mod
if not exist "%MOD%" mkdir "%MOD%"
xcopy /e /i /y /q "%HERE%Cities_Skylines\RaccoonCitySkylines" "%MOD%" >nul || goto fail
echo   -^> %MOD%

echo === Resident Evil 2 files
if not exist "%RE2%\dinput8.dll" echo   WARNING: REFramework (dinput8.dll) is not installed in RE2 yet - see SETUP_GUIDE.md step 3.
if not exist "%RE2%\reshade-shaders\Shaders\ReShade.fxh" echo   WARNING: ReShade with Standard effects is not installed in RE2 yet - see SETUP_GUIDE.md step 4.
xcopy /e /i /y /q "%HERE%Resident_Evil_2" "%RE2%" >nul || goto fail
echo   -^> %RE2%\reframework\plugins\RaccoonSkylines.dll
echo   -^> %RE2%\reframework\autorun\raccoon_skylines.lua
echo   -^> %RE2%\reshade-shaders\Shaders\RaccoonSkylines.fx
echo.
echo Done. Next: SETUP_GUIDE.md steps 7 and 8 (enable the mod in Cities: Skylines, enable the effect in ReShade).
pause
exit /b 0

:remove
del /q "%RE2%\reframework\plugins\RaccoonSkylines.dll" "%RE2%\reframework\autorun\raccoon_skylines.lua" "%RE2%\reshade-shaders\Shaders\RaccoonSkylines.fx" 2>nul
if exist "%MOD%" rmdir /s /q "%MOD%"
echo Removed. (Settings in "%LOCALAPPDATA%\Colossal Order\Cities_Skylines\RaccoonCitySkylines*.json" and
echo "%RE2%\reframework\data\raccoon_skylines" were left; delete them if you like.)
pause
exit /b 0

:fail
echo Copy failed. Is the game running? Close it and try again.
pause
exit /b 1
