Raccoon City Skylines v0.1 - Cities: Skylines x Resident Evil 2 (2019)

Start with SETUP_GUIDE.md. Short version:
  1. Install REFramework and ReShade (with full add-on support, Standard effects) into RE2.
  2. Run INSTALL.bat.
  3. Cities: Skylines: enable the mod, run windowed at 960x540, load a city with a police station.
  4. RE2: in ReShade (Home), enable RaccoonSkylines and set RESHADE_DEPTH_INPUT_IS_REVERSED=1.
  5. Start both games. F9 in Cities: Skylines switches between the skyline feed and building.

Experimental: compiled and tested without the games, not yet run inside them.
Source: https://github.com/mmcvey02/ResidentEternal
